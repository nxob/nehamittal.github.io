---
title: "Portfolio"
permalink: /portfolio/
---

Showcase selected projects:

- **Project A (LLM Recs)** — brief description and link.
- **Project B (RAG)** — what it does and your role.
- **Project C (Open‑source)** — repo link.
