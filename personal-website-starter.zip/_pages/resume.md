---
title: "Resume"
permalink: /resume/
---

- [Download my 1‑page Resume (PDF)](/assets/docs/Resume.pdf)
