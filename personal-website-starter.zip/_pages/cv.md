---
title: "CV"
permalink: /cv/
---

- [Download my CV (PDF)](/assets/docs/CV.pdf)  
- Short bio, education, and experience highlights go here.
