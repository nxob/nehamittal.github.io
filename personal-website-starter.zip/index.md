---
layout: single
author_profile: true
---

Hi! I’m **Your Name**, a Machine Learning Engineer focused on LLMs, recommendation systems, and NLP.
I currently work at **Your Company** and hack on research with **Your Lab/Group**.

My interests include **Differential Privacy**, **Algorithmic Fairness**, and **Responsible AI**.
When I’m not at the keyboard, I’m reading sci‑fi and writing blog posts (coming soon!).

If you'd like to collaborate or just say hello, reach out via LinkedIn or email :)
