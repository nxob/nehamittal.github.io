# Personal Website Starter (GitHub Pages + Minimal Mistakes)

1. Create a public repo named `<your-username>.github.io` on GitHub.
2. Download this folder and upload its contents to the repo.
3. Commit & push. GitHub Pages will build automatically.
4. Visit `https://<your-username>.github.io` in ~1–2 minutes.

Customize `_config.yml`, `_data/navigation.yml`, your pages under `_pages/`, and replace `assets/img/avatar.jpg`, `assets/docs/Resume.pdf`/`CV.pdf` with your own files.
